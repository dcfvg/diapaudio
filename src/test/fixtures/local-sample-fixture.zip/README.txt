diapaudio local sample fixture
